<?php
// Koneksi ke database
$host = "localhost";
$username = "root";
$password = "";
$dbname = "db_pkl";
$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Tangkap data POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nama_lengkap = $_POST["nama_lengkap"];
    $jenis_kelamin = $_POST["jenis_kelamin"];
    $nomor_telepon = $_POST["nomor_telepon"];
    $alamat = $_POST["alamat"];
    $nama_sekolah = $_POST["nama_sekolah"];
    $program_studi = $_POST["program_studi"];

    // Cek apakah ada ID yang dikirim untuk update (edit)
    if (isset($_POST["id"]) && !empty($_POST["id"])) {
        $id = $_POST["id"];
        // Perbarui data dalam database
        $sql = "UPDATE profile SET 
                nama_lengkap='$nama_lengkap', 
                jenis_kelamin='$jenis_kelamin', 
                nomor_telepon='$nomor_telepon', 
                alamat='$alamat', 
                nama_sekolah='$nama_sekolah', 
                program_studi='$program_studi' 
                WHERE id='$id'";
        
        if ($conn->query($sql) === TRUE) {
            echo "<h2>Data berhasil diperbarui!</h2>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        // Simpan data baru jika tidak ada ID
        $sql = "INSERT INTO profile (nama_lengkap, jenis_kelamin, nomor_telepon, alamat, nama_sekolah, program_studi) 
                VALUES ('$nama_lengkap', '$jenis_kelamin', '$nomor_telepon', '$alamat', '$nama_sekolah', '$program_studi')";
        
        if ($conn->query($sql) === TRUE) {
            echo "<h2>Data berhasil disimpan!</h2>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

// Menampilkan tombol untuk kembali ke form
echo "<a href='profile.php'><button>Kembali ke Form</button></a>";

$conn->close();
?>
