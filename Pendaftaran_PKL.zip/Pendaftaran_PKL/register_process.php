<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pkl";

// Koneksi ke database
$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $pendaftaran_id = $_POST['pendaftaran_id'];
    $nama_sekolah = $_POST['nama_sekolah'];
    $program_studi = $_POST['program_studi'];
    $tanggal_mulai = $_POST['tanggal_mulai'];
    $tanggal_selesai = $_POST['tanggal_selesai'];
    $status = $_POST['status'];

    $sql = "INSERT INTO pkl (pendaftaran_id, nama_sekolah, program_studi, tanggal_mulai, tanggal_selesai, status) 
            VALUES ('$pendaftaran_id', '$nama_sekolah', '$program_studi', '$tanggal_mulai', '$tanggal_selesai', '$status')";

    if ($conn->query($sql) === TRUE) {
        echo "Data berhasil disimpan. <a href='profile_view.php'>Lihat Data</a>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>